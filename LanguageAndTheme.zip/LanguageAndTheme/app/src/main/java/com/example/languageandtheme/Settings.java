package com.example.languageandtheme;

public class Settings extends  {
}
